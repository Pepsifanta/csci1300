#include <iostream>
// add libraries needed for code
using namespace std;

int main(){
    // type sentence that needs to be produced and end line
    cout<<"Hello, World!"<<endl;
}