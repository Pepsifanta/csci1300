#include <iostream>
#include "Enemy.h"
#include "Item.h"
#include "Player.h"
#include "Freddy.h"
#include <fstream>

using namespace std; 

int main()
{

/////////////////////////////
//testing Enemy class
Enemy u3 = Enemy("Roxy",6);
cout << u3.getEnemyBody() << endl;
cout << u3.getEnemyLevel() << endl;
//expected output 
//Roxy
//6

///////////////////////////////
//testing Freddy class
 Freddy health_1;// calling default constructor
    double current_health= health_1.getFreddyHealth();
    cout<< "Freddy's current health: "<< current_health<<endl;
    
    double initial_health = 1000;
    Freddy health_2 = Freddy(initial_health);
    cout<<"Freddy's health after charge:"<< health_2.getFreddyHealth()<<endl;
//expected output 
// Freddy's current health: 0
// account 2 balance:1000

/////////////////////////////
//testing Item class
Item it2= Item("Flashlight",10);
cout << it2.getItem() << endl;
cout << it2.getCost() << endl;
//expected output 
//Flashlight
//10

///////////////////////////////
//testing Player class
 Player player_health;// calling default constructor
    double current_phealth= player_health.getPlayerHealth();
    cout<< "Gregory's current health: "<< current_health<<endl;
    
    double initial_health2 = 1000-10;
    Player phealth_2 = Player(initial_health2);
    cout<<"Gregory's health after damages:"<< phealth_2.getPlayerHealth()<<endl;
//expected output 
// Gregory's current health: 0
// Gregory's health after damages:990

}