#ifndef GAME_H
#define GAME_H
#include <fstream>
#include <iostream>
#include <vector>
#include "Enemy.h"
#include "Item.h"
#include "Freddy.h"
#include "Player.h"
using namespace std;
//****************** what is in the post.cpp
class Game
{
        private:
            // static const int posts_size_= 50;
            // static const int users_size_= 50;
            vector<Enemy> v;
            vector<Item> item;
            //User users_[50];
            int user_health = 0;
            int Freddy_health = 0;
            
        public: 
        //Default: constructor
            Game();

            //Parameterized: constructor 
            Game(int, int);

            int getFreddyHealth();

            int getPlayerHealth();
            // int Item();
            //int Cost();

            int fightEnemy(string fight);
            void showInvetory(string bag);
            void getTime(string time);
            int solveRiddle(int answer);
            int playGame(int product);
            // int getLikes(string post_author, string username);
            // void getTime(string username_tag);
            // bool addPost(string post_body, string post_author, string date);
            // void printPopularPosts(int count, string year);
            // //User findLeastActiveUser();
            // int countUniqueLikes(string post_author);

            

};
//tell compiler to read it 
#endif