#ifndef PLAYER_H //<- Helps when calling a class
#define PLAYER_H//<- Defines the class

using namespace std;

class Player
{
    public: //where functions go
    //constructors:
    //default
    Player();//constructor: new object w/ banlance=0
    //overloaded/parameterized
    Player(int initial_health);// new object
 
    void p_damage(int amount); //mutator
    //void add_interest(double rate);
    //----------------------------------
    //Accessors:
    const int getPlayerHealth(); //accessor

private: //where variables go
    int player_health; //where the balance resides

};
#endif